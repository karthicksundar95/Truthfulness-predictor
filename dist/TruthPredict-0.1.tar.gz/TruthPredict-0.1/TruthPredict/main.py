### Truth Fullness predictor control flow
'''
    File name: main.py
    Author: Karthick Sundar C K
    Date created: 01/02/2024
    Date last modified: 07/02/2024
    Python Version: 3.10
'''


