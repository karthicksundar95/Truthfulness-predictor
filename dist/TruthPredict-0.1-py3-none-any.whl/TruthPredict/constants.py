### File to include all the constant/literal values or variable name assignments to cater future adjustments not affecting the code base
# constants
TARGET_COLUMN = "Label"
SUBJECTS = 'subjects'
SPEAKER_NAME = 'speaker_name'
STATEMENT = 'statement'
STATEMENT_CONTEXT = 'statement_context'
CVSPLITS = 5